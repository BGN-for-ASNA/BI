tadaLikelihood <- function(parVect, nbdadata,type){

if(is.character(nbdadata)){
	
		totalLikelihood <- 0;
			
		for(i in 1:length(nbdadata)){
			subdata <- eval(as.name(nbdadata[i]));
			totalLikelihood <- totalLikelihood+ tadaLikelihood(parVect= parVect, nbdadata=subdata, type=type);
			}
					
		return(totalLikelihood);
					
}else{

	#Define required function
	sumWithoutNA <- function(x) sum(na.omit(x))

	#calculate the number of each type of parameter
	noSParam <- dim(nbdadata@stMetric)[2] #s parameters
	noILV<- dim(nbdadata@ILVdata)[2] #ILV effects on asocial learning
	datalength <- length(nbdadata@id) #ILV effects on social transmission
	
	#Extract vector giving which naive individuals were present in the diffusion for each acqusition event
	presentInDiffusion<-nbdadata@ presentInDiffusion
	
	#assign different paramreter values to the right vectors
	rate<-1/parVect[1];
	shape<-parVect[2]
	sParam <- parVect[3:(2+noSParam)]
	asocialCoef <- parVect[(noSParam+3):(2+noSParam+ noILV)]
	if(type=="unconstrained"){stCoef <- parVect[(noSParam+ noILV+3):(2+noSParam+ 2*noILV)]}
	
	# create a matrix of the coefficients to multiply by the observed data values, only if there are asocial variables 
	asocialCoef.mat <- matrix(data=rep(asocialCoef, datalength), nrow=datalength, byrow=T)
	asocial.sub <- nbdadata@ILVdata
	asocialLP <- apply(asocialCoef.mat*asocial.sub, MARGIN=1, FUN=sum)

	if(type=="unconstrained"){ # unconstrained
		stCoeff.mat <- matrix(data=rep(stCoef, datalength), nrow=datalength, byrow=T)
		st.sub <- nbdadata@ILVdata
		socialLP <- apply(stCoeff.mat*st.sub, MARGIN=1, FUN=sum)
	}
	if(type=="additive"){ # additive
		socialLP <- rep(0, datalength)
	}
	if(type=="multiplicative"){ # multiplicative
		socialLP <- asocialLP
	}
	
	sParam.mat <- matrix(data=rep(sParam, datalength), nrow=datalength, byrow=T) # create a matrix of sParams 
	unscaled.st <- apply(sParam.mat*nbdadata@stMetric, MARGIN=1, FUN=sum)

	#The totalRate (relative) is set to zero for naive individuals not in the diffusion for a given event
	totalRate <- (exp(asocialLP) + exp(socialLP)*unscaled.st)* presentInDiffusion

	cHazTstart<--pgamma(c(0,nbdadata@timeAcq[-length(nbdadata@timeAcq)]),shape=shape,rate=rate, lower = FALSE, log = TRUE)
	cHazTend <--pgamma(nbdadata@timeAcq,shape=shape,rate=rate, lower = FALSE, log = TRUE)
	HazTend<-dgamma(nbdadata@timeAcq,shape=shape,rate=rate)/(pgamma(nbdadata@timeAcq,shape=shape,rate=rate, lower = FALSE))
	
	#Take logs and add across acquisition events
	lComp1 <- sum(log(totalRate[nbdadata@status==1])) # group by skilled
	
	lComp2.1 <- tapply(totalRate, INDEX=nbdadata@event.id, FUN=sum) # check this works. this is total rate per event across all naive id
	lComp2.2 <- sum(log(lComp2.1))
	
	lComp3.1<-lComp2.1*(cHazTstart-cHazTend)
	lComp3.2<-sum(lComp3.1)
	
	lComp4<-sum(HazTend)
	
	#I need to add some Smetrics etc to the data object to fit the final period- leave out for now	
	lComp5<-0
	
	negloglik <- lComp3.2 - lComp1 - lComp4
	
	return(negloglik)
	}
}

#Constrains parameters to be equal (or differ by a specified amount), or set to zero (or a specific value)
#And returns the corresponding logLik for specified values of the free parameters

oadaLikelihood.constrained <- function(parVect, nbdadata,constraintsVect=1:length(parVect),offsetVect=NULL,type){

	if(is.null(offsetVect)) offsetVect=rep(0,length(constraintsVect))

	#calculate the number of each type of parameter
	noSParam <- dim(nbdadata@stMetric)[2] #s parameters
	noILV<- dim(nbdadata@ILVdata)[2] #ILV effects on asocial learning
	parVectLength<-noSParam + noILV +(type=="unconstrained")*noILV
	
	newParVect<-rep(NA,parVectLength)
	
	for(i in unique(constraintsVect)){	
		if (i == 0) {newParVect[constraintsVect==0]<-0}else{
			newParVect[constraintsVect==i]<-parVect[i]
	}}
	
	newParVect<-newParVect+ offsetVect

	return(oadaLikelihood(parVect= newParVect, nbdadata= nbdadata,type=type))

}



