#The directory will need changing for your computer

source('gradient_fn.R', chdir = TRUE)
source('nbdaData.R', chdir = TRUE)
source('oadalikelihood.R', chdir = TRUE)
source('oadaFit.R', chdir = TRUE)
source('hessian_fn.R', chdir = TRUE)
source('sampSizeExtract.R', chdir = TRUE)
source('oadaAICtable.R', chdir = TRUE)
source('profLikCI.R', chdir = TRUE)
source('constrainedNBDAdata.R', chdir = TRUE)
source('asocialLikelihood.R', chdir = TRUE)
source('asocialGradient_fn.R', chdir = TRUE)
source('oadaPropSolveByST.R', chdir = TRUE)

#######################################################################################################################################
#Examples of how to construct the nbdaData objects
#######################################################################################################################################

#CONSTANT IVLs and MULTIPLE s parameters: 
amg1 <- matrix(data = c(0.0, 8.0, 6.5, 5.0, 1.0,  8.0, 0.0, 7.5, 2.0, 5.0,6.5, 7.5, 0.0, 2.0, 3.5,6.0, 2.0, 2.0, 0.0, 0.5,1.0, 5.0, 3.5, 0.5, 0.0), nrow=5) 
amg2 <- matrix(data = c(0.0, 8.5, 6.0, 4.0, 1.0, 8.0, 0.0, 7.5, 3.0, 5.0, 6.5, 7.5, 0.0, 2.0, 3.5, 7.0, 2.0, 2.0, 0.0, 0.8,1.0, 4.0, 3.5, 0.9, 0.0), nrow=5) 
amg3 <- matrix(data = c(0.0, 7.5, 6.0, 3.0, 1.0, 8.0, 0.0, 7.5, 3.0, 5.0, 6.5, 6.5, 0.0, 7.0, 3.5, 7.0, 2.0, 2.0, 0.0, 0.8, 1.0, 2.0, 2.5, 0.9, 0.0), nrow=5) 
n.assMatrix <- 3 
assMatrix3 <- array(data = c(amg1,amg2,amg3), dim=c(nrow(amg1), ncol(amg1), n.assMatrix))
oag1t1 <- c(4,1,2) 
agonrank <- matrix(data = c(2.24, 6.55, 0.75, 3.20, 0.35), nrow=5, byrow=F) 
comprank <- matrix(data = c(3,4,2,1,5), nrow=5, byrow=F) 
novEnv <- matrix(data = c(-0.44487, -3.13171, 0.72296, 1.12335, 1.73027), nrow=5, byrow=F) 
objNeo <- matrix(data = c(2.09151, -1.99598, -0.40689, -0.23706, 0.54842), nrow=5, byrow=F) 
AsocLearn <- matrix(data = c(-0.56429, -0.14960, -0.33799, -0.69712, 1.74900), nrow=5, byrow=F) 
asoc <- c("agonrank", "comprank", "novEnv","objNeo", "AsocLearn") 
label <- "nG1T1" 
tempData <- nbdaData(label=label, assMatrix=assMatrix3, asoc=asoc, orderAcq=oag1t1,asocialTreatment="constant") 
print(tempData)

#Now also works with seeded demonstrators
tempData2 <- nbdaData(label=label, assMatrix=assMatrix3, asoc=asoc, orderAcq=oag1t1,asocialTreatment="constant",demons=c(0,0,1,0,0))
print(tempData2)

tempData3 <- nbdaData(label=label, assMatrix=assMatrix3, asoc=asoc, orderAcq=oag1t1,asocialTreatment="constant",weights=c(10,10,100,100,1000)) 
print(tempData3)


#TIME-VARYING IVLs and MULTIPLE s parameters: 
amg1 <- matrix(data = c(0.0, 8.0, 6.5, 5.0, 1.0,  8.0, 0.0, 7.5, 2.0, 5.0,6.5, 7.5, 0.0, 2.0, 3.5,6.0, 2.0, 2.0, 0.0, 0.5,1.0, 5.0, 3.5, 0.5, 0.0), nrow=5) 
amg2 <- matrix(data = c(0.0, 8.5, 6.0, 4.0, 1.0, 8.0, 0.0, 7.5, 3.0, 5.0, 6.5, 7.5, 0.0, 2.0, 3.5, 7.0, 2.0, 2.0, 0.0, 0.8,1.0, 4.0, 3.5, 0.9, 0.0), nrow=5) 
amg3 <- matrix(data = c(0.0, 7.5, 6.0, 3.0, 1.0, 8.0, 0.0, 7.5, 3.0, 5.0, 6.5, 6.5, 0.0, 7.0, 3.5, 7.0, 2.0, 2.0, 0.0, 0.8, 1.0, 2.0, 2.5, 0.9, 0.0), nrow=5) 
n.assMatrix <- 3 
assMatrix3 <- array(data = c(amg1,amg2,amg3), dim=c(nrow(amg1), ncol(amg1), n.assMatrix))
oag1t1 <- c(4,1,2) 
agonrank <- matrix(data = c(c(2.24, 6.55, 0.75, 3.20, 0.35), c(2.25, 6.54, 0.74, 3.21, 0.36),c(2.23, 6.56, 0.76, 3.19, 0.33)), nrow=5, byrow=F) 
comprank <- matrix(data = c(c(3,4,2,1,5), c(2,5,1,2,4),c(4,3,3,3,6)), nrow=5, byrow=F) 
novEnv <- matrix(data = c(c(-0.44487, -3.13171, 0.72296, 1.12335, 1.73027), c(-0.44587, -3.13271, 0.72496, 1.12135, 1.73527),c(-0.44287, -3.13371, 0.72396, 1.12235, 1.73127)), nrow=5, byrow=F) 
objNeo <- matrix(data = c(c(2.09151, -1.99598, -0.40689, -0.23706, 0.54842), c(2.09251, -1.99498, -0.40589, -0.23806, 0.54742),c(2.09351, -1.99698, -0.40789, -0.23606, 0.54942)), nrow=5, byrow=F) 
AsocLearn <- matrix(data = c(c(-0.56429, -0.14960, -0.33799, -0.69712, 1.74900), c(-0.56329, -0.14860, -0.33699, -0.69512, 1.74700),c(-0.56529, -0.14760, -0.33899, -0.69612, 1.74800)), nrow=5, byrow=F) 
AsocLearn <- matrix(data = c(-0.56429, -0.14960, -0.33799, -0.69712, 1.74900), nrow=5, byrow=F) 
asoc <- c("agonrank", "comprank", "novEnv","objNeo", "AsocLearn") 
label <- "nG1T1" 
tempData <- nbdaData(label=label, assMatrix=assMatrix3, asoc=asoc, orderAcq=oag1t1,asocialTreatment="timevarying")
print(tempData) 



#CONSTANT IVLs and SINGLE s parameter: 
amg1 <- matrix(data = c(0.0, 8.0, 6.5, 5.0, 1.0,  8.0, 0.0, 7.5, 2.0, 5.0,6.5, 7.5, 0.0, 2.0, 3.5,6.0, 2.0, 2.0, 0.0, 0.5,1.0, 5.0, 3.5, 0.5, 0.0), nrow=5) 
n.assMatrix <- 1 
assMatrix1 <- array(data = amg1, dim=c(nrow(amg1), ncol(amg1), n.assMatrix)) 
agonrank <- matrix(data = c(2.24, 6.55, 0.75, 3.20, 0.35), nrow=5, byrow=F) 
comprank <- matrix(data = c(3,4,2,1,5), nrow=5, byrow=F) 
novEnv <- matrix(data = c(-0.44487, -3.13171, 0.72296, 1.12335, 1.73027), nrow=5, byrow=F) 
objNeo <- matrix(data = c(2.09151, -1.99598, -0.40689, -0.23706, 0.54842), nrow=5, byrow=F) 
asoc <- c("agonrank", "comprank", "novEnv","objNeo", "AsocLearn") 
label <- "nG1T1" 
tempData <- nbdaData(label=label, assMatrix=assMatrix1, asoc=asoc, orderAcq=oag1t1, asocialTreatment="constant") 
print(tempData) 



#TIME-VARYING IVLs and SINGLE s parameter
amg1 <- matrix(data = c(0.0, 8.0, 6.5, 5.0, 1.0,  8.0, 0.0, 7.5, 2.0, 5.0,6.5, 7.5, 0.0, 2.0, 3.5,6.0, 2.0, 2.0, 0.0, 0.5,1.0, 5.0, 3.5, 0.5, 0.0), nrow=5) 
n.assMatrix <- 1 
assMatrix1 <- array(data = amg1, dim=c(nrow(amg1), ncol(amg1), n.assMatrix)) 
oag1t1 <- c(4,1,2) 
agonrank <- matrix(data = c(c(2.24, 6.55, 0.75, 3.20, 0.35), c(2.25, 6.54, 0.74, 3.21, 0.36),c(2.23, 6.56, 0.76, 3.19, 0.33)), nrow=5, byrow=F) 
comprank <- matrix(data = c(c(3,4,2,1,5), c(2,5,1,2,4),c(4,3,3,3,6)), nrow=5, byrow=F) 
novEnv <- matrix(data = c(c(-0.44487, -3.13171, 0.72296, 1.12335, 1.73027), c(-0.44587, -3.13271, 0.72496, 1.12135, 1.73527),c(-0.44287, -3.13371, 0.72396, 1.12235, 1.73127)), nrow=5, byrow=F) 
objNeo <- matrix(data = c(c(2.09151, -1.99598, -0.40689, -0.23706, 0.54842), c(2.09251, -1.99498, -0.40589, -0.23806, 0.54742),c(2.09351, -1.99698, -0.40789, -0.23606, 0.54942)), nrow=5, byrow=F) 
AsocLearn <- matrix(data = c(c(-0.56429, -0.14960, -0.33799, -0.69712, 1.74900), c(-0.56329, -0.14860, -0.33699, -0.69512, 1.74700),c(-0.56529, -0.14760, -0.33899, -0.69612, 1.74800)), nrow=5, byrow=F) 
AsocLearn <- matrix(data = c(-0.56429, -0.14960, -0.33799, -0.69712, 1.74900), nrow=5, byrow=F) 
asoc <- c("agonrank", "comprank", "novEnv","objNeo", "AsocLearn") 
label <- "nG1T1" 
tempData <- nbdaData(label=label, assMatrix=assMatrix1, asoc=asoc, orderAcq=oag1t1, asocialTreatment="timevarying")
print(tempData) 


#CONSTANT ILVs, MULTIPLE s parameters with time varying nets:
#assMatrixIndex specifies which part of the array (dimension 4) applies for each event
#I have just put the same number for all dyads in each part of the network so it is easier to check the indexing by event is working properly
assMatrixTV <- array(NA,dim=c(5,5,3,2))
assMatrixIndex=c(1,1,2)
#Network 1
#Time period 1 (events 1 and 2)
assMatrixTV[,,1,1]<-1
#Time period 2 (event 3)
assMatrixTV[,,1,2]<-2
#Network 2
#Time period 1 (events 1 and 2)
assMatrixTV[,,2,1]<-3
#Time period 2 (event 3)
assMatrixTV[,,2,2]<-4
#Network 3
#Time period 1 (events 1 and 2)
assMatrixTV[,,3,1]<-5
#Time period 2 (event 3)
assMatrixTV[,,3,2]<-6
#view the structure
assMatrixTV

n.assMatrix <- 3 
oag1t1 <- c(4,1,2) 
agonrank <- matrix(data = c(2.24, 6.55, 0.75, 3.20, 0.35), nrow=5, byrow=F) 
comprank <- matrix(data = c(3,4,2,1,5), nrow=5, byrow=F) 
novEnv <- matrix(data = c(-0.44487, -3.13171, 0.72296, 1.12335, 1.73027), nrow=5, byrow=F) 
objNeo <- matrix(data = c(2.09151, -1.99598, -0.40689, -0.23706, 0.54842), nrow=5, byrow=F) 
AsocLearn <- matrix(data = c(-0.56429, -0.14960, -0.33799, -0.69712, 1.74900), nrow=5, byrow=F) 
asoc <- c("agonrank", "comprank", "novEnv","objNeo", "AsocLearn") 
label <- "nG1T1" 
tempData <- nbdaData(label=label, assMatrix=assMatrixTV, asoc=asoc, orderAcq=oag1t1,asocialTreatment="constant",assMatrixIndex= assMatrixIndex) 
print(tempData)


#######################################################################################################################################
#Fitting models using oadaFit
#######################################################################################################################################

#set seed to get the same results as me... change this to get some variation in the simulations
set.seed(3)

#Simulate some diffusion data (don't worry about error messages here)
noInd<-100
s<-3
baseRate<-1/100

socialNet<-matrix(0, ncol=noInd, nrow=noInd)
for(i in 0:9){socialNet[i*10+(1:10),i*10+(1:10)]<-runif(100,0.5,1)}

x1<-rnorm(noInd)
x2<-rnorm(noInd)

asocialLP<-x2*1

x1 <- matrix(data = x1, nrow=nrow(socialNet), byrow=F) 
x2 <- matrix(data = x2, nrow=nrow(socialNet), byrow=F) 

z<-rep(0,noInd)
orderAcq<-timeAcq <-rep(NA,noInd)
runningTime<-0

for(i in 1:noInd){
	rate<-baseRate*(exp(asocialLP)+s*z%*%t(socialNet))*(1-z)
	times<-rexp(noInd,rate)
	times[is.nan(times)]<-Inf
	orderAcq [i]<-which(times==min(times))[1]
	runningTime<-runningTime+min(times)
	timeAcq[i]<-runningTime
	z[which(times==min(times))[1]]<-1
}
	
	
n.assMatrix <- 1 
assMatrix1 <- array(data = socialNet, dim=c(nrow(socialNet), ncol(socialNet), n.assMatrix)) 
asoc <- c("x1","x2") 
label <- "simData" 
nbdaDataObject <- nbdaData(label=label, assMatrix=assMatrix1, asoc=asoc, orderAcq= orderAcq, asocialTreatment="constant") 

#Model with social transmission and both ILVs
#NOW WORKS FOR TYPE ADDITIVE AND MULTIPLICATIVE, UNCONSTRAINED TO FOLLOW
model.multi<-oadaFit(nbdaDataObject,type="multiplicative")
model.multi
model.add<-oadaFit(nbdaDataObject,type="additive")
model.add
model.multi@outputPar
model.add@outputPar

#Should now also work with multiple diffusions
model2.multi<-oadaFit(c("nbdaDataObject","nbdaDataObject"),type="multiplicative")
model2.multi
model2.add<-oadaFit(c("nbdaDataObject","nbdaDataObject"),type="additive")
model2.add
model2.multi@outputPar
model2.add@outputPar

#Standard errors should get smaller as we double the number of data
model.multi@se
model.add@se
model2.multi@se
model2.add@se

#Note that standard errors are now provided
#Fitting should be much more reliable because we have coded a gradient function

#NOW INSTEAD OF FITTING CONSTRAINED MODELS DIRECTLY, YOU CREATE A NEW DATASET WHICH CORRESPONDS TO A MODEL WITH CONSTRAINED PARAMETERS AS FOLLOWS

#Model with social transmission and only the second ILV
NoILV1<-constrainedNBDAdata(nbdadata=nbdaDataObject,constraintsVect=c(1,0,2),offsetVect=NULL)
model3.multi<-oadaFit(NoILV1,type="multiplicative")
model3.multi
model3.add<-oadaFit(NoILV1,type="additive")
model3.add
model3.multi@outputPar
model3.add@outputPar

#Same with mulitple diffusions- objects with same constraints need to be created for each diffusion
model4.multi<-oadaFit(c("NoILV1","NoILV1"),type="multiplicative")
model4.multi
model4.add<-oadaFit(c("NoILV1","NoILV1"),type="additive")
model4.add
model4.multi@outputPar
model4.add@outputPar

#Model with social transmission and only the second ILV
NoILV1or2<-constrainedNBDAdata(nbdadata=nbdaDataObject,constraintsVect=c(1,0,0),offsetVect=NULL)
model3b.multi<-oadaFit(NoILV1or2,type="multiplicative")
model3b.multi
model3b.add<-oadaFit(NoILV1or2,type="additive")
model3b.add
model3b.multi@outputPar
model3b.add@outputPar

model3b.add<-oadaFit(NoILV1or2,type="asocial")
model3b.add



#Now a model in which the coefficent of ILV 2 is constrained to a value of 0.5- create a new object with this offset encoded
ILV1at0point5<-constrainedNBDAdata(nbdadata=nbdaDataObject,constraintsVect=c(1,0,2),offsetVect=c(0,0.5,0))
#Offset is encoded here:
ILV1at0point5@offsetCorrection

model5.multi<-oadaFit(c("ILV1at0point5","ILV1at0point5"),type="multiplicative")
model5.multi
#Compare outputs
model4.multi@outputPar
model5.multi@outputPar

#To fit a model with no social transmission and both ILVs we now use the same object as the unconstrained model but use type="asocial"
model2.asocial<-oadaFit(c("nbdaDataObject","nbdaDataObject"),type="asocial")
model2.asocial
model2.multi@outputPar
model2.add@outputPar
model2.asocial@outputPar

#######################################################################################################################################
#Fitting a set of models order by AICc, do model averaging etc.
#######################################################################################################################################

#Specify the set of models required as a set of constrainsts on the parameters
constraintsVect<-rbind(
c(1,2,3),
c(1,0,0),
c(1,2,0),
c(1,0,2),
c(1,2,3),
c(1,0,0),
c(1,2,0),
c(1,0,2),
c(1,2,3),
c(1,0,0),
c(1,2,0),
c(1,0,2)
)

#And the type of model to be fitted in each case.
typeVect<-rep(c("multiplicative","additive","asocial"),each=4)

#Fit all the models and display as a table
table1<-oadaAICtable(nbdaDataObject,typeVect, constraintsVect)
print(table1)

#Alternatively we can specify 0s for the s parameters and the function recognises and fits the asocial models automatically
constraintsVect<-rbind(
  c(1,2,3),
  c(1,0,0),
  c(1,2,0),
  c(1,0,2),
  c(1,2,3),
  c(1,0,0),
  c(1,2,0),
  c(1,0,2),
  c(0,1,0),
  c(0,0,1),
  c(0,1,2),
  c(0,0,0)
)
typeVect<-c(rep("multiplicative",4),rep("additive",7))
#Note that asocial models are identified automatically
#Fit all the models and display as a table
table1<-oadaAICtable(nbdaDataObject,typeVect, constraintsVect)
print(table1)


#Get support for model types and for each variable
typeSupport(table1)
variableSupport(table1)
#Then do model averaging with unconditional standard errors
modelAverageEstimates(table1)
unconditionalStdErr(table1)

#We can also do the model averaging across a specified model type
#Including asocial models by default (the same in this case)
variableSupport(table1,typeFilter="multiplicative")
modelAverageEstimates(table1,typeFilter="multiplicative")
unconditionalStdErr(table1,typeFilter="multiplicative")

#Now excluding asocial models (may come out the same if asocial models have little weight)
variableSupport(table1,typeFilter="multiplicative",includeAsocial=F)
modelAverageEstimates(table1,typeFilter="multiplicative",includeAsocial=F)
unconditionalStdErr(table1,typeFilter="multiplicative",includeAsocial=F)

#Now just across asocial models
variableSupport(table1,typeFilter="asocial")
modelAverageEstimates(table1,typeFilter="asocial")
unconditionalStdErr(table1,typeFilter="asocial")

#######################################################################################################################################
#Getting 95% confidence intervals using profile likelihood techniques
#This is vital for s parameters since CIs based on SEs will be highly misleading due to frequent assymetry in the profile likelihood 
#######################################################################################################################################

#Plot the profile likelihood to get an idea where the 95% CIs are
#which=1 means we are doing it for the first parameter in the nbdadata object
plotProfLik(which=1,model=model2.add,range=c(0,30))
#95% CI are where the profile liklihood crosses the dashed line, so we can "zoom in" by respecifying the range of th plot
#And increasing the resolution (number of points plotted)
plotProfLik(which=1,model=model2.add,range=c(1,10),resolution=100)

#If you set the seed to the same as me above, your lower 95% CI is in the range 2-3 and the upper is in the range 8-10
#we specify this in the function to find them precisely
profLikCI(which=1,model=model2.add,upperRange=c(8,10),lowerRange=c(2,3))
#Lower CI  Upper CI 
#2.618540 9.236488

#We can do this for the second ILV (which =3) as follows:
#Plot the profile likelihood to get an idea where the 95% CIs are
plotProfLik(which=3,model=model2.add,range=c(-5,5))
#zoom in
plotProfLik(which=3,model=model2.add,range=c(0.3,1.5),resolution=20)
profLikCI(which=3,model=model2.add,upperRange=c(1.2,1.5),lowerRange=c(0.4,0.6))
#Lower CI  Upper CI 
#0.4569169 1.4669007 

